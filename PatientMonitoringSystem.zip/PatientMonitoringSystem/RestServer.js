const app = require('express')();
const parser = require("body-parser");
const fs = require("fs");
const dir = __dirname;


app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());


let patients = [];

function readData(){
    const filename = "data.json";
    const jsonContent = fs.readFileSync(filename, 'utf-8');
    patients = JSON.parse(jsonContent);
}

function saveData(){
    const filename = "data.json";
    const jsonData = JSON.stringify(patients);
    fs.writeFileSync(filename, jsonData, 'utf-8');
}
app.get("/patients", (req, res)=>{
    readData();
    res.send(JSON.stringify(patients));    
})

app.get("/patients/:id", (req, res)=>{
    const patientid = req.params.id;
    if(patients.length == 0){
        readData();
    }
    let foundRec = patients.find((e) => e.patientId == patientid);
    if(foundRec == null)
        throw "Patient not found";
    res.send(JSON.stringify(foundRec))
})

app.put("/patients", (req, res)=>{
    if(patients.length == 0)
        readData();
    let body = req.body;
    for (let index = 0; index < patients.length; index++) {
        let element = patients[index];
        if (element.patientId == body.patientId) {
            element.patientName = body.patientName;
            element.pAge=body.pAge;
            element.pAddress = body.pAddress;
            element.pDepartment = body.pDepartment;
            element.phno=body.phno;
            element.date=body.date;
            saveData();
            res.send("Patient updated successfully");
        }
    }
})

app.post('/patients', (req, res)=>{
    if (patients.length == 0)
        readData();//Fill the array if it is not loaded....
    let body = req.body;//parsed data from the POST...
    patients.push(body);  
    saveData();//updating to the JSON file...
    res.send("Patient added successfully");
})
app.delete("/patients/:id", (req, res)=>{
  const pid = req.params.id;
  if(patients.length == 0){
      readData();
  }
  let foundRec = patients.find((e) => e.patientId == pid);
  if(foundRec == null)
      throw "Patient not found";
      for (let index = 0; index < patients.length; index++) {
        let element = patients[index];
        if (element.patientId == pid)
        {patients.splice(index, 1);
            saveData();
            res.send("Patient Deleted sucessfully");}
        }
})
app.listen(1234, ()=>{
    console.log("Server available at 1234");
})